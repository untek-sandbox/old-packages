<?php

namespace ZnBundle\Eav\Yii2\Api;

use yii\base\Module as YiiModule;

class Module extends YiiModule
{

}
