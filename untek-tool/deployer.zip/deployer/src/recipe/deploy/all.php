<?php

namespace Deployer;

use ZnCore\Code\Helpers\PhpHelper;

PhpHelper::requireFromDirectory(__DIR__);
