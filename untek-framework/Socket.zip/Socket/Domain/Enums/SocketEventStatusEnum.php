<?php

namespace Untek\Framework\Socket\Domain\Enums;

class SocketEventStatusEnum {

    const OK = 200;
    const ERROR = 500;

}
