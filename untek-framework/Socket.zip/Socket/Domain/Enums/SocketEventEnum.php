<?php

namespace Untek\Framework\Socket\Domain\Enums;

class SocketEventEnum {

    const CONNECT = 'connect';
    const DISCONNECT = 'disconnect';
    const MESSAGE = 'message';

}
